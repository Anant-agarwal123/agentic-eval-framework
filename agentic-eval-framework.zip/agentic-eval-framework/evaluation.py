# evaluate.py
import numpy as np
import pandas as pd

# Import scalar-scoring functions from your metric modules
from metrics.instruction   import instr_score
from metrics.hallucination import hallu_score
from metrics.assumption    import assump_score
from metrics.accuracy      import acc_score
from metrics.coherence     import coher_score

# ----------------------------
# Weights & neutral fills
# ----------------------------
DEFAULT_WEIGHTS = {
    "instr_score":  0.15,
    "hallu_score":  0.25,
    "assump_score": 0.25,
    "acc_score":    0.20,
    "coher_score":  0.15,
}

# If any metric is missing/NaN, fill with these neutral defaults
NEUTRAL_FILL = {
    "instr_score": 0.0,  # conservative for instruction
    "hallu_score": 0.5,  # neutral when context missing
    "assump_score":0.5,  # neutral when context missing
    "acc_score":   0.0,  # per your policy: no_gold => 0
    "coher_score": 0.5,  # neutral for empty response
}

METRIC_COLS = ["instr_score","hallu_score","assump_score","acc_score","coher_score"]

# ----------------------------
# Core evaluation
# ----------------------------
def evaluate_responses(
    df: pd.DataFrame,
    weights: dict | None = None,
    question_col: str = "question",
    context_col: str  = "context",
    gold_col: str     = "gold_reference",
    resp_col: str     = "ai_response",
    flags: dict | None = None,  # optionally provide precomputed flags per row
) -> pd.DataFrame:
    """
    Compute the five metric scores and a weighted final_score.

    Expected columns in df:
      - question, context, gold_reference, ai_response
      - (optional flags) is_unanswerable, context_missing, no_gold

    Returns a NEW DataFrame with columns:
      instr_score, hallu_score, assump_score, acc_score, coher_score, final_score
    """
    weights = weights or DEFAULT_WEIGHTS
    out = df.copy()

    # Gracefully get flags from df (or provided dict), defaulting to False
    def _get_flag(row, key, default=False):
        if flags and key in flags:
            return flags[key]
        val = row.get(key, default)
        # normalize truthy strings like "true"/"1"
        s = str(val).strip().lower()
        return s in {"1","true","yes","y","t"}

    # Compute each metric (lean scalar versions)
    out["instr_score"]  = out.apply(
        lambda r: instr_score(r.get(question_col, ""), r.get(resp_col, "")),
        axis=1
    )

    out["hallu_score"]  = out.apply(
        lambda r: hallu_score(
            r.get(context_col, ""), r.get(resp_col, ""),
            _get_flag(r, "is_unanswerable", False),
            _get_flag(r, "context_missing", False)
        ),
        axis=1
    )

    out["assump_score"] = out.apply(
        lambda r: assump_score(
            r.get(context_col, ""), r.get(resp_col, ""),
            _get_flag(r, "is_unanswerable", False),
            _get_flag(r, "context_missing", False)
        ),
        axis=1
    )

    out["acc_score"]    = out.apply(
        lambda r: acc_score(
            r.get(gold_col, ""), r.get(resp_col, ""),
            _get_flag(r, "no_gold", False)
        ),
        axis=1
    )

    out["coher_score"]  = out[resp_col].apply(coher_score)

    # Fill neutrals, coerce, and clip
    for k, neutral in NEUTRAL_FILL.items():
        out[k] = pd.to_numeric(out[k], errors="coerce").fillna(neutral).clip(0, 1)

    # Weighted final score
    out["final_score"] = (
        weights["instr_score"]  * out["instr_score"]  +
        weights["hallu_score"]  * out["hallu_score"]  +
        weights["assump_score"] * out["assump_score"] +
        weights["acc_score"]    * out["acc_score"]    +
        weights["coher_score"]  * out["coher_score"]
    ).astype(float)

    return out

# ----------------------------
# Ranking helpers (optional)
# ----------------------------
def add_rank_per_question(
    df_scored: pd.DataFrame,
    question_col: str = "question",
    score_col: str = "final_score",
    top_k: int | None = None
) -> pd.DataFrame:
    """
    Add rank within each question based on final_score (descending).
    If top_k is provided, returns only top-k rows per question.
    """
    out = df_scored.copy()
    out["rank_in_question"] = (
        out.groupby(question_col)[score_col]
           .rank(method="first", ascending=False)
           .astype(int)
    )
    if top_k is not None:
        out = out[out["rank_in_question"] <= top_k].copy()
    return out

METRIC_COLS = ["instr_score","hallu_score","assump_score","acc_score","coher_score"]

def build_question_dict(
    df_scored: pd.DataFrame,
    question_col: str = "question",
    context_col: str  = "context",
    gold_col: str     = "gold_reference",
    resp_col: str     = "ai_response",
    score_col: str    = "final_score",
    top_k: int        = 5,
    question_id_col: str | None = None,
    round_to: int = 4
) -> dict:
    """
    Build {qid: {question, context, gold_reference, responses:[{text, scores:{...}, rank}]}}.
    'scores' includes each of the 5 metrics + final_score for LLM-friendly interpretation.
    """
    df = df_scored.copy()

    # Determine numeric IDs
    if question_id_col and question_id_col in df.columns:
        df["_qid"] = df[question_id_col]
    else:
        uniq = df[question_col].astype(str).str.strip().drop_duplicates().tolist()
        qid_map = {q: i+1 for i, q in enumerate(uniq)}
        df["_qid"] = df[question_col].astype(str).str.strip().map(qid_map)

    # Ensure numeric & clipped
    for c in METRIC_COLS + [score_col]:
        if c in df.columns:
            df[c] = pd.to_numeric(df[c], errors="coerce").clip(lower=0, upper=1)

    qdict = {}
    for qid, group in df.groupby("_qid", sort=False):
        g = group.copy()
        g[score_col] = pd.to_numeric(g[score_col], errors="coerce").fillna(0.0)
        g = g.sort_values(score_col, ascending=False).head(top_k)

        responses = []
        for i, (_, row) in enumerate(g.iterrows(), start=1):
            # assemble per-response scores
            scores = {"final_score": round(float(row[score_col]), round_to)}
            for c in METRIC_COLS:
                if c in g.columns:
                    val = row[c]
                    scores[c] = None if pd.isna(val) else round(float(val), round_to)

            responses.append({
                "text": row.get(resp_col, ""),
                "scores": scores,
                "rank": i
            })

        first = group.iloc[0]
        qdict[int(qid)] = {
            "question":       str(first.get(question_col, "")),
            "context":        str(first.get(context_col, "")),
            "gold_reference": str(first.get(gold_col, "")),
            "responses":      responses
        }

    return qdict


# ----------------------------
# Convenience: quick combine (equal weights)
# ----------------------------
def add_simple_final_score(df: pd.DataFrame) -> pd.DataFrame:
    """
    If you’ve already computed the five metric columns, add a simple equal-weight average.
    """
    out = df.copy()
    for m in METRIC_COLS:
        if m not in out.columns:
            out[m] = np.nan
        out[m] = pd.to_numeric(out[m], errors="coerce")
    out["final_score"] = out[METRIC_COLS].mean(axis=1, skipna=True)
    return out
