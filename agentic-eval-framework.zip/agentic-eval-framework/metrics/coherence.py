# metrics/coherence.py
import re
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity
from .utils import to_text, sent_split

def _coherence_subscores(resp_raw: str):
    resp = to_text(resp_raw).strip()
    if not resp:
        return 0.0, 0.0, 0.0, 0.0, 0.0  # repetition, fluency, contradiction, flow, completeness

    # (1) Repetition penalty (bigrams/trigrams)
    tokens = resp.split()
    n = len(tokens)
    bigrams  = [" ".join(tokens[i:i+2]) for i in range(n-1)]
    trigrams = [" ".join(tokens[i:i+3]) for i in range(n-2)]
    rep_ratio = 0.0
    if bigrams or trigrams:
        uniq = len(set(bigrams + trigrams))
        total = len(bigrams + trigrams) or 1
        rep_ratio = 1.0 - (uniq / total)  # higher = more repetition
    repetition = 1.0 - min(rep_ratio, 1.0)  # invert → higher = better

    # (2) Fluency proxy
    punct_ratio = len(re.findall(r"[^\w\s]", resp)) / max(len(resp), 1)
    avg_len = np.mean([len(w) for w in tokens]) if tokens else 0
    fluency = 1.0
    if punct_ratio > 0.15: fluency -= 0.3
    if avg_len < 2:        fluency -= 0.3
    if avg_len > 12:       fluency -= 0.3
    fluency = max(0.0, fluency)

    # (3) Contradiction proxy
    ents = set(re.findall(r"\b[A-Z][a-z]+\b", resp))
    nums = set(re.findall(r"\d+(?:\.\d+)?", resp))
    contradictions = 0
    for e in ents | nums:
        hits = re.findall(rf"(?:^|\W)(?:not|never)\s+\b{re.escape(str(e))}\b", resp, re.I)
        if len(hits) > 0 and resp.lower().count(str(e).lower()) > 1:
            contradictions += 1
    contradiction = 1.0 - min(contradictions, 3) / 3.0

    # (4) Logical flow (adjacent sentence similarity)
    sents = sent_split(resp)
    flow = 1.0
    if len(sents) >= 2:
        vect = TfidfVectorizer(min_df=1, ngram_range=(1, 2))
        try:
            X = vect.fit_transform(sents)
            sims = cosine_similarity(X)
            adj = [sims[i, i+1] for i in range(len(sents)-1)]
            mean_sim = float(np.mean(adj)) if adj else 0.0
            flow = float(np.clip(mean_sim, 0.0, 1.0))
        except ValueError:
            flow = 0.0

    # (5) Completeness (proper end punctuation)
    completeness = 1.0 if resp[-1] in ".?!" else 0.5

    return float(repetition), float(fluency), float(contradiction), float(flow), float(completeness)

def coher_score(ai_response: str,
                weights=(0.25, 0.20, 0.15, 0.25, 0.15)) -> float:
    """
    Coherence score in [0,1], higher = more coherent.
    Preserves original logic; returns only the final score.
    """
    r = to_text(ai_response)
    rep, flu, con, flw, comp = _coherence_subscores(r)
    w_rep, w_flu, w_con, w_flw, w_comp = weights
    score = (w_rep*rep + w_flu*flu + w_con*con + w_flw*flw + w_comp*comp)
    return float(min(1.0, max(0.0, score)))
