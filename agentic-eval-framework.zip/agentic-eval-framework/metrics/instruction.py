# metrics/instruction.py
import re
from .utils import to_text, normalize_text, word_count

def instr_score(question: str, response: str) -> float:
    """
    Graded, cumulative instruction-following score in [0,1].
    Multiple cues (bullets + summary + word count + paragraph) apply additive penalties.
    """
    q = question
    r = response

    if not r:
        return 0.0

    score = 1.0  # start perfect, subtract penalties

    # --- Bulleted list required ---
    if ("bullet" in q) or ("bulleted" in q) or ("•" in q) or ("list" in q):
        # consider -, *, •, or numbered lists like "1. "
        bullet_pat = re.compile(r'^\s*(?:[-*•]|\d+\.)\s+', re.M)
        if "â€¢" in r:
            pass
        elif not bullet_pat.search(r):
            score -= 0.5  # strong penalty if bullets requested but not used

    # --- Exact word count requested ---
    m = re.search(r"(\d+)\s*words?", q)
    if m:
        target = int(m.group(1))
        wc = word_count(r)
        deviation = abs(wc - target)
        if deviation <= 1:
            pass           # no penalty
        elif deviation <= 3:
            score -= 0.3
        elif deviation <= 5:
            score -= 0.5
        else:
            score -= 1.0   # effectively fails this requirement

    # --- Paragraph requested ---
    if "paragraph" in q:
        wc = word_count(r)
        nonempty_lines = [ln for ln in r.splitlines() if ln.strip()]
        single_para = (len(nonempty_lines) <= 1)
        if single_para and wc > 20:
            pass           # good paragraph
        elif single_para and wc > 10:
            score -= 0.3   # short but acceptable
        else:
            score -= 0.7   # not a proper paragraph

    # --- Summarize / Expand requested ---
    if any(kw in q for kw in ["summarize", "summary", "expand", "elaborate"]):
        wc = word_count(r)
        if wc > 50:
            pass           # well-expanded/summary with substance
        elif wc > 20:
            score -= 0.3
        elif wc > 5:
            score -= 0.5
        else:
            score -= 0.8   # far too short to qualify

    # clamp to [0,1]
    score = float(max(0.0, min(1.0, score)))
    return score
