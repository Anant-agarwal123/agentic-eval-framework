# metrics/utils.py
import re
import pandas as pd

# =============================
# Safe text cleaning
# =============================
def to_text(x) -> str:
    """Convert value safely to string, handling None/NaN."""
    if x is None:
        return ""
    try:
        if pd.isna(x):
            return ""
    except Exception:
        pass
    return str(x)

def normalize_text(s: str) -> str:
    """Lowercase, strip, collapse whitespace."""
    s = to_text(s).lower().strip()
    return re.sub(r"\s+", " ", s)

# =============================
# Flags (context/gold state)
# =============================
UNANSWERABLE_MARKERS = {
    "unanswerable","not answerable","cannot be determined","insufficient context",
    "not available in passage","unknown","na","n/a"
}

def derive_flags(row):
    """Given a row, derive is_unanswerable, context_missing, no_gold flags."""
    gold = to_text(row.get("gold_reference","")).lower()
    ctx  = to_text(row.get("context",""))
    is_unanswerable = gold in UNANSWERABLE_MARKERS
    context_missing = (ctx.strip() == "")
    no_gold = (gold.strip() == "")
    return pd.Series({
        "is_unanswerable": is_unanswerable,
        "context_missing": context_missing,
        "no_gold": no_gold
    })

# =============================
# Text parsing
# =============================
def sent_split(raw: str):
    """Split text into sentences using simple regex rules."""
    raw = to_text(raw)
    parts = re.split(r"[\.?!;\n]+", raw)
    return [p.strip() for p in parts if p and p.strip()]

def extract_numbers(s: str):
    """Return list of numeric substrings from text."""
    return re.findall(r"\d+(?:\.\d+)?", to_text(s))

def extract_entities_simple(raw: str):
    """Simple regex-based entity extraction (capitalized words/phrases)."""
    raw = to_text(raw)
    multi = re.findall(r"\b([A-Z][a-z]+(?:\s+[A-Z][a-z]+)+)\b", raw)
    single = re.findall(r"\b[A-Z][a-z]+\b", raw)
    ents = set(single)
    for phrase in multi:
        ents.add(phrase)
        ents.update(phrase.split())
    return list(ents)

# =============================
# Boolean helpers
# =============================
def safe_bool(x) -> bool:
    """Parse common True/False string values."""
    s = to_text(x).strip().lower()
    return s in {"1","true","yes","y","t"}

BOOL_YES = {"yes","true","correct","right","affirmative","y"}
BOOL_NO  = {"no","false","incorrect","wrong","negative","n"}

def parse_boolean(s: str):
    """Map normalized text to boolean if possible."""
    t = normalize_text(s)
    if t in BOOL_YES: return True
    if t in BOOL_NO:  return False
    return None

# =============================
# Instruction-specific
# =============================
WORD_RX = re.compile(r"[A-Za-zÀ-ÖØ-öø-ÿ\u0900-\u097F0-9]+(?:[-’'][A-Za-z0-9]+)?")

def word_count(t: str) -> int:
    """Word count that preserves contractions and hyphenated terms."""
    return len(WORD_RX.findall(t or ""))

# =============================
# No-answer template detection
# =============================
NOANSWER_PATTERNS = [
    "no answer","not in passage","not within passage","not stated",
    "cannot be determined","cannot be found","insufficient information",
    "unknown","not specified","no information","answer not available",
    "cannot determine","not provided","information is missing"
]

def no_answer_template(s: str) -> bool:
    """Check if a response looks like a 'no-answer' template."""
    s = normalize_text(s)
    return any(p in s for p in NOANSWER_PATTERNS)
