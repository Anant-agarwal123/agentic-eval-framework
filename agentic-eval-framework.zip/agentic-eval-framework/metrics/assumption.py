# metrics/assumption.py
import re
from .utils import (
    to_text, normalize_text, sent_split, extract_entities_simple, extract_numbers,
    no_answer_template, safe_bool
)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

# lightweight lexicon for speculative language
_SPECULATIVE = {
    "probably","likely","appears","seems","may","might","could","assume","assuming",
    "suggests","it is possible","typically","usually","generally","perhaps",
    "apparently","reportedly","supposedly","presumably"
}

def _speculative_count(resp_norm: str) -> int:
    c = 0
    for w in _SPECULATIVE:
        if re.search(rf"\b{re.escape(w)}\b", resp_norm):
            c += 1
    return c

def assump_score(context: str,
                 response: str,
                 is_unanswerable=False,
                 context_missing=False,
                 weights=(0.35, 0.20, 0.15, 0.30)) -> float:
    """
    Assumption Control (context-only). Higher = better (fewer unstated assumptions).
    Uses:
      1) New-claim detection (entities & numbers novel to context)
      2) Content overlap ratio (context vs response tokens)
      3) Speculative language penalty
      6) Sentence→Context TF-IDF MaxSim (avg best per response sentence)
      7) Unanswerable handling (cap/bonus)

    Returns:
      assump_score ∈ [0,1]
    """
    ctx_raw  = to_text(context)
    resp_raw = to_text(response)
    ctx_miss = safe_bool(context_missing)
    is_unans = safe_bool(is_unanswerable)

    # If no context → neutral
    if ctx_miss or not ctx_raw.strip():
        return 0.5

    # Normalized strings
    ctx_norm  = normalize_text(ctx_raw)
    resp_norm = normalize_text(resp_raw)

    # (1) New Claim Detection
    resp_ents = set(extract_entities_simple(resp_raw))
    ctx_ents  = set(extract_entities_simple(ctx_raw))
    resp_nums = set(extract_numbers(resp_norm))
    ctx_nums  = set(extract_numbers(ctx_norm))
    total_claims = max(len(resp_ents) + len(resp_nums), 1)
    new_claims = sum(1 for e in resp_ents if e not in ctx_ents) + sum(1 for n in resp_nums if n not in ctx_nums)
    ucr = 1.0 - (new_claims / total_claims)  # higher = better (fewer new claims)

    # (2) Content Overlap Ratio
    resp_tokens = set(resp_norm.split())
    ctx_tokens  = set(ctx_norm.split())
    overlap = len(resp_tokens & ctx_tokens) / (len(resp_tokens) or 1)

    # (3) Speculative Language Penalty → map to score in [0,1]
    spec_cnt = _speculative_count(resp_norm)
    spec_score = max(0.0, 1.0 - min(spec_cnt, 3)/3.0)

    # (6) Sentence→Context TF-IDF MaxSim (avg of best per resp sentence)
    ssms = 0.0
    r_sents = sent_split(resp_raw)
    c_sents = sent_split(ctx_raw)
    if r_sents and c_sents:
        vect = TfidfVectorizer(min_df=1, ngram_range=(1,2))
        try:
            X = vect.fit_transform(c_sents + r_sents)
            C = X[:len(c_sents)]
            R = X[len(c_sents):]
            sims = cosine_similarity(R, C)  # [R x C]
            ssms = float(sims.max(axis=1).mean()) if sims.size else 0.0
        except ValueError:
            ssms = 0.0

    # Combine (weights: UCR, Overlap, Speculative, SSMS)
    w_u, w_o, w_s, w_m = weights
    score = w_u*ucr + w_o*overlap + w_s*spec_score + w_m*ssms

    # (7) Unanswerable handling
    templ = no_answer_template(resp_norm)
    if is_unans and new_claims > 0:
        score = min(score, 0.5)              # answered despite being unanswerable → cap
    if is_unans and templ and new_claims == 0:
        score = min(1.0, score + 0.1)        # correct refusal with no new claims → small bonus

    return float(max(0.0, min(1.0, score)))
