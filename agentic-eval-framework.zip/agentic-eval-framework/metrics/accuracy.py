# metrics/accuracy.py
import re
import math
from .utils import to_text, normalize_text, parse_boolean, no_answer_template

# Optional date parsing (kept, but module is optional)
try:
    import dateparser
except Exception:
    dateparser = None

# ---------------------------
# Local text normalization (punct stripped)
# ---------------------------
def _normalize_basic(s: str) -> str:
    s = normalize_text(s)
    s = re.sub(r"[^\w\s]", " ", s)   # strip punctuation
    s = re.sub(r"\s+", " ", s)
    return s

# ---------------------------
# Numbers & Units (same logic, cleaned)
# ---------------------------
_UNIT_FACTORS = {
    # length
    "mm": ("m", 1e-3), "cm": ("m", 1e-2), "m": ("m", 1.0), "km": ("m", 1e3),
    # mass
    "mg": ("kg", 1e-6), "g": ("kg", 1e-3), "kg": ("kg", 1.0),
    # volume
    "ml": ("l", 1e-3), "l": ("l", 1.0),
}
_NUM_UNIT_RE = re.compile(r"(?P<num>\d+(?:\.\d+)?)\s*(?P<unit>[a-zA-Z]+)?")

def _extract_numbers_units(s: str):
    """List[(value:float, base_unit:str|None)] — converts to base if unit known."""
    out = []
    for m in _NUM_UNIT_RE.finditer(to_text(s)):
        val = float(m.group("num"))
        u = m.group("unit").lower() if m.group("unit") else None
        if u in _UNIT_FACTORS:
            base, factor = _UNIT_FACTORS[u]
            out.append((val * factor, base))
        else:
            out.append((val, None))
    return out

def _compare_single_number(gold_s: str, resp_s: str, rel_tol=0.02, abs_tol=0.5) -> float:
    g = _extract_numbers_units(gold_s)
    r = _extract_numbers_units(resp_s)
    if len(g) != 1 or len(r) != 1:
        return 0.0
    (gv, gu), (rv, ru) = g[0], r[0]
    if gu and ru and gu != ru:
        return 0.0
    diff = abs(rv - gv)
    if (abs(gv) >= 1 and diff/abs(gv) <= rel_tol) or diff <= abs_tol:
        return 1.0
    return 0.0

def _compare_multi_numbers(gold_s: str, resp_s: str, rel_tol=0.02, abs_tol=0.5) -> float:
    G = _extract_numbers_units(gold_s)
    R = _extract_numbers_units(resp_s)
    if not G or not R:
        return 0.0
    hits, used = 0, set()
    for rv, ru in R:
        best_j, best_diff = None, float("inf")
        for j, (gv, gu) in enumerate(G):
            if j in used: 
                continue
            if (gu and ru) and (gu != ru):
                continue
            diff = abs(rv - gv)
            if (abs(gv) >= 1 and diff/abs(gv) <= rel_tol) or (diff <= abs_tol):
                if diff < best_diff:
                    best_diff = diff; best_j = j
        if best_j is not None:
            hits += 1; used.add(best_j)
    prec = hits / len(R)
    rec  = hits / len(G)
    return (2*prec*rec/(prec+rec)) if (prec+rec) else 0.0

# ---------------------------
# Dates
# ---------------------------
def _parse_date_ymd(s: str):
    if not dateparser:
        return None, None
    raw = to_text(s).strip()
    if not raw: return None, None
    dt = dateparser.parse(raw)
    if not dt: return None, None
    gran = "day"
    if re.fullmatch(r"\d{4}", raw): gran = "year"
    elif re.search(r"^\w+\s+\d{4}$", raw, re.I) or re.search(r"^\d{4}-\d{2}$", raw):
        gran = "month"
    return dt, gran

def _compare_dates(gold_s: str, resp_s: str) -> float:
    gdt, ggran = _parse_date_ymd(gold_s)
    rdt, rgran = _parse_date_ymd(resp_s)
    if not gdt or not rdt:
        return 0.0
    gran = ggran or "day"
    if gran == "year":
        return 1.0 if gdt.year == rdt.year else 0.0
    if gran == "month":
        return 1.0 if (gdt.year == rdt.year and gdt.month == rdt.month) else 0.0
    return 1.0 if (gdt.year == rdt.year and gdt.month == rdt.month and gdt.day == rdt.day) else 0.0

# ---------------------------
# Token F1 & ROUGE-L
# ---------------------------
def _tokens(s: str):
    return _normalize_basic(s).split()

def _token_f1(gold: str, resp: str) -> float:
    g = _tokens(gold); r = _tokens(resp)
    if not g and not r: return 1.0
    if not g or not r:  return 0.0
    g_counts = {}
    for t in g: g_counts[t] = g_counts.get(t, 0) + 1
    match = 0
    for t in r:
        if g_counts.get(t, 0) > 0:
            match += 1; g_counts[t] -= 1
    prec = match / len(r)
    rec  = match / len(g)
    return (2*prec*rec/(prec+rec)) if (prec+rec) else 0.0

def _rouge_l_f1(gold: str, resp: str) -> float:
    g, r = _tokens(gold), _tokens(resp)
    if not g or not r: return 0.0
    m, n = len(g), len(r)
    dp = [[0]*(n+1) for _ in range(m+1)]
    for i in range(m):
        for j in range(n):
            if g[i] == r[j]:
                dp[i+1][j+1] = dp[i][j] + 1
            else:
                dp[i+1][j+1] = max(dp[i][j+1], dp[i+1][j])
    lcs = dp[m][n]
    prec = lcs / n
    rec  = lcs / m
    return (2*prec*rec/(prec+rec)) if (prec+rec) else 0.0

# ---------------------------
# Lists / sets
# ---------------------------
_ITEM_SEP_RE = re.compile(r"[;\n]|(?:\s*,\s*)|(?:\s+and\s+)|(?:•)")

def _split_items(s: str):
    return [p.strip() for p in _ITEM_SEP_RE.split(to_text(s)) if p and p.strip()]

def _list_f1(gold_s: str, resp_s: str) -> float:
    g_items = [_normalize_basic(x) for x in _split_items(gold_s)]
    r_items = [_normalize_basic(x) for x in _split_items(resp_s)]
    if not g_items and not r_items: return 1.0
    if not g_items or not r_items:  return 0.0
    hits, used = 0, set()
    for r in r_items:
        best_j, best_sim = None, 0.0
        rt = set(_tokens(r))
        for j, g in enumerate(g_items):
            if j in used: continue
            gt = set(_tokens(g))
            inter = len(rt & gt); union = len(rt | gt) or 1
            sim = inter/union
            if r == g: sim = 1.0
            if sim > best_sim:
                best_sim = sim; best_j = j
        if best_j is not None and best_sim >= 0.6:
            hits += 1; used.add(best_j)
    prec = hits / len(r_items)
    rec  = hits / len(g_items)
    return (2*prec*rec/(prec+rec)) if (prec+rec) else 0.0

# ---------------------------
# Type detection
# ---------------------------
def _detect_type(gold_raw: str) -> str:
    g = to_text(gold_raw).strip()
    g_norm = _normalize_basic(g)
    if "||" in g:
        return "aliases"
    if parse_boolean(g_norm) is not None:
        return "boolean"
    if dateparser and dateparser.parse(g):
        return "date"
    nums = _extract_numbers_units(g)
    if len(nums) >= 2: return "numeric_multi"
    if len(nums) == 1: return "numeric_single"
    if len(_split_items(g)) >= 2: return "list"
    return "short_text" if len(_tokens(g)) <= 5 else "long_text"

# ---------------------------
# Scoring a (gold, response) pair
# ---------------------------
def _score_pair(gold_raw: str, resp_raw: str) -> float:
    g = to_text(gold_raw); r = to_text(resp_raw)
    g_norm = _normalize_basic(g); r_norm = _normalize_basic(r)

    t = _detect_type(g)

    if t == "aliases":
        cands = [x.strip() for x in g.split("||") if x.strip()]
        best = 0.0
        for cand in cands:
            s = _score_pair(cand, r)
            if s > best: best = s
        return best

    if t == "boolean":
        gb = parse_boolean(g_norm); rb = parse_boolean(r_norm)
        return 1.0 if (rb is not None and rb == gb) else 0.0

    if t == "date" and dateparser:
        return _compare_dates(g, r)

    if t == "numeric_single":
        return _compare_single_number(g, r)

    if t == "numeric_multi":
        return _compare_multi_numbers(g, r)

    if t == "list":
        return _list_f1(g, r)

    if t == "short_text":
        em = 1.0 if g_norm == r_norm else 0.0
        f1 = _token_f1(g, r)
        return max(em, 0.5*em + 0.5*f1)

    # long_text
    f1 = _token_f1(g, r)
    rl = _rouge_l_f1(g, r)
    return 0.6*f1 + 0.4*rl

# ---------------------------
# Public API: accuracy score ONLY
# ---------------------------
def acc_score(gold_reference: str, ai_response: str, no_gold=False) -> float:
    """
    Accuracy vs GOLD ONLY (no context). Returns acc_score ∈ [0,1].
    Rules kept:
      - If no_gold=True or empty gold → score = 0.0 (your chosen policy)
      - If gold indicates 'unanswerable' → 1.0 if response is a no-answer template else 0.0
      - Else type-specific scoring (boolean, numeric w/ units + tolerance, date, list F1, short/long text)
      - Multi-gold aliases supported via '||' (take best)
    """
    gold_raw = to_text(gold_reference)
    resp_raw = to_text(ai_response)
    no_gold_flag = str(to_text(no_gold)).strip().lower() in {"1","true","yes","y","t"}

    # No gold → penalize as 0.0
    if no_gold_flag or gold_raw.strip() == "":
        return 0.0

    # Gold says unanswerable
    if no_answer_template(gold_raw):
        return 1.0 if no_answer_template(resp_raw) else 0.0

    # Otherwise, score by type
    score = _score_pair(gold_raw, resp_raw)
    return float(min(1.0, max(0.0, score)))
