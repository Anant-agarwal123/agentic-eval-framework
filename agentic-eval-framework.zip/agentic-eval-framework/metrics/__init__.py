# metrics/__init__.py
from .instruction import instr_score
from .hallucination import hallu_score
from .assumption import assump_score
from .accuracy import acc_score
from .coherence import coher_score

__all__ = ["instr_score", "hallu_score", "assump_score", "acc_score", "coher_score"]
