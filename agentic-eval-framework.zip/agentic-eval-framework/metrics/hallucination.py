# metrics/hallucination.py
from .utils import (
    to_text, normalize_text, extract_entities_simple, extract_numbers,
    no_answer_template, safe_bool
)
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def hallu_score(context: str,
                response: str,
                is_unanswerable=False,
                context_missing=False,
                weights=(0.5, 0.3, 0.2),
                tau_bonus=0.2) -> float:
    """
    Hallucination = groundedness w.r.t. CONTEXT only (no gold).
    Returns a float in [0,1]. Higher = less hallucination (more grounded).

    Logic (kept from your earlier version, just without diagnostics):
      - If context missing/empty → neutral 0.5.
      - Subscores:
          sim   : TF-IDF cosine(context, response)
          ent   : entity/number overlap ratio
          claim : token overlap ratio (response tokens within context)
      - Combine: w_sim*sim + w_ent*ent + w_claim*claim
      - Unanswerable:
          * If is_unanswerable and response is a no-answer template AND ent>0.8 → +tau_bonus (cap 1.0)
          * If is_unanswerable and response tries to answer → cap at 0.6
    """

    # Flags & strings (safe)
    ctx_raw  = to_text(context)
    resp_raw = to_text(response)
    is_unans = safe_bool(is_unanswerable)
    ctx_miss = safe_bool(context_missing)

    # If no context → neutral
    if ctx_miss or not ctx_raw.strip():
        return 0.5

    # Normalized forms
    ctx_norm  = normalize_text(ctx_raw)
    resp_norm = normalize_text(resp_raw)

    # ---- TF-IDF cosine similarity ----
    sim = 0.0
    if ctx_norm and resp_norm:
        vect = TfidfVectorizer(min_df=1, ngram_range=(1,2))
        try:
            tfidf = vect.fit_transform([ctx_norm, resp_norm])
            sim = float(cosine_similarity(tfidf[0], tfidf[1])[0, 0])
        except ValueError:
            sim = 0.0

    # ---- Entity/number overlap ----
    resp_ents = set(extract_entities_simple(resp_raw))
    ctx_ents  = set(extract_entities_simple(ctx_raw))
    resp_nums = set(extract_numbers(resp_norm))
    ctx_nums  = set(extract_numbers(ctx_norm))

    total_claims = max(len(resp_ents) + len(resp_nums), 1)
    ent_hits = len(resp_ents & ctx_ents)
    num_hits = len(resp_nums & ctx_nums)
    ent = (ent_hits + num_hits) / total_claims  # in [0,1]

    # ---- Claim density (token overlap) ----
    resp_tokens = set(resp_norm.split())
    ctx_tokens  = set(ctx_norm.split())
    claim = len(resp_tokens & ctx_tokens) / (len(resp_tokens) or 1)

    # ---- Combine subscores ----
    w_sim, w_ent, w_claim = weights
    final = w_sim * sim + w_ent * ent + w_claim * claim

    # ---- Unanswerable handling (same as before, just internal) ----
    templ = no_answer_template(resp_raw)
    if is_unans:
        if templ and ent > 0.8:
            final = min(1.0, final + float(tau_bonus))
        elif not templ:
            final = min(final, 0.6)

    # clamp
    return float(min(1.0, max(0.0, final)))
