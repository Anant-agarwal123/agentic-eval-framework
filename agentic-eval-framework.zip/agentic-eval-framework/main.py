# main.py
import argparse
import json
import pandas as pd
from evaluation import evaluate_responses, build_question_dict

def parse_args():
    p = argparse.ArgumentParser(description="Agentic Evaluation – batch scorer")
    p.add_argument("-i", "--input", required=True, help="Path to input CSV")
    p.add_argument("-o", "--output", required=True, help="Path to output scored CSV")
    p.add_argument("-j", "--json", help="Optional: path to export question dictionary JSON")
    p.add_argument("--top_k", type=int, default=5, help="Top-k responses per question for JSON export")
    p.add_argument("--qid_col", type=str, default=None, help="Optional: numeric question id column name")
    return p.parse_args()

def main():
    args = parse_args()

    # Load
    df = pd.read_csv(args.input, encoding_errors="replace")

    # (Optional) normalize common column aliases
    rename_map = {
        "reference": "gold_reference",
        "gold": "gold_reference",
        "answer": "ai_response",
        "response": "ai_response",
    }
    for k, v in rename_map.items():
        if k in df.columns and v not in df.columns:
            df.rename(columns={k: v}, inplace=True)
    for c in ["question", "context", "gold_reference", "ai_response"]:
        if c not in df.columns:
            df[c] = ""

    # Score
    df_scored = evaluate_responses(df)

    # Save scored CSV
    df_scored.to_csv(args.output, index=False)
    print(f"[OK] Scored CSV → {args.output}")

    # Optional: export per-question dictionary JSON with top-k responses
    if args.json:
        qdict = build_question_dict(
            df_scored,
            question_col="question",
            context_col="context",
            gold_col="gold_reference",
            resp_col="ai_response",
            score_col="final_score",
            top_k=args.top_k,
            question_id_col=args.qid_col,
        )
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(qdict, f, ensure_ascii=False, indent=2)
        print(f"[OK] Question JSON → {args.json}")

if __name__ == "__main__":
    main()
