# Agentic Evaluation Framework (P4)

**e6data × IIT BHU Hackathon 2025 – Problem 4: Agentic Evaluation**

## Problem Statement
Evaluating AI agent responses at scale is challenging. We need a framework that can:
- Judge **instruction-following**
- Detect **hallucination**
- Prevent **assumptions**
- Ensure **coherence**
- Measure **accuracy**

Our framework automatically scores thousands of responses in batch mode and outputs **interpretable metrics** and **ranked results** to generate rankings of all responses based on easy to understand scoring methodology.

---

## Schema of dataset
- Four columns named 'question', 'context', 'reference' and 'response'
- Synthetic dataset was created mixing the SQuAD dataset available on Kaggle and AI generated data, so as to have a good mix of various types of prompts given by user.

---


## Features
- Five metric scores: `instr_score`, `hallu_score`, `assump_score`, `acc_score`, `coher_score`
- Weighted `final_score` for each response
- Batch processing for large datasets
- JSON export with per-question ranked responses
- Interpretable: each response includes subscores for explainability
- Lightweight (scikit-learn, pandas, numpy, rapidfuzz) – no heavy GPUs/LLMs required

---

## Project Structure
```
agentic-eval-framework/
│
├── data/
│   └── synthetic_dataset.csv  
├── out/                        
│   ├── scored.csv              
│   └── questions.json          
├── metrics/                    
│   ├── accuracy.py
│   ├── assumption.py
│   ├── coherence.py
│   ├── hallucination.py
│   ├── instruction.py
│   ├── utils.py
│   └── __init__.py
├── evaluate.py                 
├── main.py                    
├── requirements.txt
└── README.md
```

---

## Setup
```bash
git clone <repo-url>
cd agentic-eval-framework
python -m venv venv
source venv/bin/activate   # (Linux/Mac)
venv\Scripts\activate      # (Windows)

pip install -r requirements.txt
```

---

## Usage

### Run on sample dataset containing 245 unique questions and 5 ai generated responses per question
```bash
python main.py -i data/synthetic_dataset.csv -o out/scored.csv -j out/questions.json --top_k 5
```

- `out/scored.csv` → adds 5 metrics + `final_score`
- `out/questions.json` → dictionary with per-question top-k ranked responses

### Sample Output (JSON)
```json
{
  "1": {
    "question": "What did the Taliban want to subject a small part of the country to?",
    "context": "In 1996, the Taliban ...",
    "gold_reference": "Islamic law",
    "responses": [
      {
        "text": "They wanted to impose Islamic law.",
        "scores": {
          "instr_score": 1.0,
          "hallu_score": 0.95,
          "assump_score": 0.9,
          "acc_score": 1.0,
          "coher_score": 0.92,
          "final_score": 0.95
        },
        "rank": 1
      },
      ...
    ]
  }
}
```

---

## Methodology
- **Instruction Score** → checks response against user instructions (format, length, bullets)
- **Hallucination Score** → compares response to context (cosine similarity, entity matching, rule-based unanswerable handling)
- **Assumption Score** → penalizes speculative claims, contradictions, or unsupported info
- **Accuracy Score** → compares to gold reference (Exact Match, token F1, ROUGE-L, semantic overlap)
- **Coherence Score** → checks fluency, readability, and flow of the response

Each score ∈ [0,1]. Weighted sum → `final_score`.

---

## Demo Video
- Shows code logs.
- Shows pipeline running on dataset.
- `scored.csv` → highlights 5 metrics + final_score
- `questions.json` → shows ranked outputs for 2–3 questions

---

## Future Scope
- Plug-in **LLM-based judges** for handling scenarios which are untouched via rule based or ML based methodology.
- Explainability of generated ranks and scores in human language again by using LLMs.
